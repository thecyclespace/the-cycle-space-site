# The Cycle Space . Visual Pack

## Contenu

- `assets/full_resolution/` : 3 créations originales en PNG et WebP, utilisables pour les visuels principaux après validation d’Elsa.
- `assets/contact_sheet_crops/` : 20 vignettes individuelles découpées de la planche de direction artistique. **Résolution limitée : elles servent de références et ne sont pas destinées à de grands affichages.**
- `previews/20_visuals_contact_sheet.png` : planche complète pour sélectionner les visuels.
- `ASSET_MANIFEST.json` : dimensions des vignettes.

## Recommandations d’intégration (React / Vite)

1. Privilégier les WebP. Ajouter `width`, `height`, `alt` et `loading=lazy` sur les images hors premier écran.
2. Pour l’image Hero, utiliser l’original horizontal `warm_airy_minimal_elegant_lifestyle_portrait_sc.webp`; prévoir un cadrage mobile propre avec `object-fit: cover`. Ne pas lazy-loader l’image LCP si elle est dans le premier écran.
3. La photo d’Elsa doit être une **vraie photo d’Elsa**, pas un portrait IA. Les portraits générés du pack sont des images d’ambiance, pas son identité.
4. Ne pas utiliser les vignettes du contact sheet comme illustrations médicales ou représentations scientifiques.
5. Garder les textes hors des fichiers image pour permettre à Elsa de les éditer via le CMS Sveltia et soutenir l’accessibilité / le SEO.
6. Déclinaisons finales à exporter, après sélection : Hero desktop 1600 x 900, Hero mobile 750 x 1000, cartes 800 x 1000, illustrations à rapport 1:1.

## Guide de style

Photographie naturelle, lumière douce dorée, matière lin/coton, crème, terracotta, rose poudré, brun doux. Éviter symboles médicaux faux ou portraits IA représentant la praticienne.

## Important

Il s’agit d’un **lot créatif exploratoire**, pas de 20 photos HD indépendamment générées. Les 20 petits fichiers sont des découpes de planche et leurs dimensions réelles figurent dans le manifeste.
